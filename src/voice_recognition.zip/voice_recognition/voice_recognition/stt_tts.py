import rclpy
from rclpy.node import Node

from time_msgs.msg import Time

class SttTtsSub(Node):

    def __init__(self):
        super().__init__('stt_tts_sub')
        self.subscription = self.create_subscription(
            Time,
            'set_alarm',
            self.listener_callback,
            10)
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        self.get_logger().info('I heard: {}, {}'.format(msg.is_first_alarm, msg.remained_time))


def main(args=None):
    rclpy.init(args=args)

    node = SttTtsSub()

    rclpy.spin(node)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
